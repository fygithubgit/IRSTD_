python setup.py build install 
